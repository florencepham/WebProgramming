1. I think I have implemented every thing correctly 
2. I discussed this project with Saurav Acharya and Duyen Nguyen
3. I spent more than 10 hours on this project. I spent the first six hours just trying to understand what is going on, what I should do. Then after that, the next 4 hours finishing the code. The last hour just figuring out how to test it with redline and mmap project. 
I found that I had to change my redline project. It did not work before, and I couldn't test it. Now I had the actually link with data that works, I could test my program, and fix it.  
