// Initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var app = express();
// See https://stackoverflow.com/questions/5710358/how-to-get-post-query-in-express-node-js
app.use(bodyParser.json());
// See https://stackoverflow.com/questions/25471856/express-throws-error-as-body-parser-deprecated-undefined-extended
app.use(bodyParser.urlencoded({ extended: true }));

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/locations';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

app.post('/sendLocation', function (request, response) {
	response.header('Access-Control-Allow-Origin', '*');
	response.set('Content-Type', 'text/html');
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lat;
	created_at = JSON.stringify(new Date());

	if (login == undefined || lat == undefined || lng == undefined) {
		response.send(500);
	} else {
		var toInsert = {
			"login": login, 
			"lat": lat,
			"lng": lng,
			"created_at" : created_at
		};

		db.collection("locations", function(err, collection) {
			collection.insert(toInsert, function (err, saved) {
				if (err) {
					response.send(500);
				} else {
					// Get all check-ins and send back JSON data
					db.collection('locations', function(er, collection) {
						var toSent = '';
						collection.find().toArray(function(err, cursor) {
							for (var i = JSON.stringify(cursor.length) - 1; i >= 0; i--) {
								toSent += JSON.stringify(cursor[i]);
								if (i > 0 && cursor.length != 1)
									toSent = toSent + ", ";

							}
							response.send('{"characters":[], "students":[' + toSent + ']}');
						});
					});
				}
			});
		});
	}
})

app.get('/locations.json', function (request, response) {
	response.header('Access-Control-Allow-Origin', '*');

	var url = require('url');
	var url_parts = url.parse(request.url, true);
	var query = url_parts.query;

	var reqLogin = query.login;

	if (reqLogin == undefined) {
		response.send("[]");
	} else { 
		db.collection("locations", function(err, collection) {
			var indexPage = '';
			collection.find({login: reqLogin}).toArray(function(err, cursor) {
				for (var i = JSON.stringify(cursor.length) - 1; i >= 0; i--) {
					indexPage += JSON.stringify(cursor[i]);
					if (i > 0 && cursor.length != 1)
						indexPage = indexPage + ", ";
				}
				response.send('[' + indexPage + ']');
			})
		})
	}
})

app.get('/', function (request, response) {
	db.collection("locations", function(err, collection) {
			var indexPage = '<p>Check-ins</p>';
			collection.find().toArray(function(err, cursor) {
				for (var i = JSON.stringify(cursor.length) - 1; i >= 0; i--) {
					indexPage += '<p>' + cursor[i].created_at + ', Login: ' + cursor[i].login + ', Lat: ' + cursor[i].lat + ', Lng: ' + cursor[i].lng + '</p>';
				}
				response.send(indexPage);
			} )
		})
})

app.get('/redline.json', function(request, response) {
	response.header('Access-Control-Allow-Origin', '*');
	var http = require('http');

	http.get("http://developer.mbta.com/lib/rthr/red.json", function(res) {
		var data = '';
		res.on('data', function(chunk) {
			data += chunk;
		});
		res.on('end', function() {
			response.send(data);
		});
	}).on('error', function(error) {
		response.send(500);
	});
})

app.listen(process.env.PORT || 3000);

